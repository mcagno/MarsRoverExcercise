namespace MarsRoverExcercise.Library
{
    public interface IPlateau
    {
        long Width { get; }
        long Length { get; }
    }
}